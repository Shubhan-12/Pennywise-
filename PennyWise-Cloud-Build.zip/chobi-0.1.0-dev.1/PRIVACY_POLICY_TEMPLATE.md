# PennyWise Privacy Policy — publication template

**Do not publish this template until the bracketed publisher details have been completed and the statements have been checked against the final release build.**

Effective date: [DATE]
Publisher: [LEGAL NAME OR DEVELOPER NAME]
Contact: [SUPPORT EMAIL]

PennyWise is an offline personal expense and budget tracker. In this source version, transaction, category, and budget records are stored locally on the device using the Room/SQLite database. The app does not include an account system, advertising SDK, analytics SDK, or app-operated server connection. The app does not transmit those records to the publisher.

Users may explicitly export a backup file or database file using the app's backup controls. The user chooses where that file is saved or shared. Exported files can contain financial records and should be stored and shared carefully. Importing a backup can add to or replace local records depending on the selected import action.

Android automatic app backup is disabled in this build. Uninstalling the app or clearing its storage can permanently remove locally stored records unless the user previously exported a backup.

This policy must be updated if the app adds cloud sync, analytics, advertising, crash reporting, account features, or any other data collection/sharing. Users can contact [SUPPORT EMAIL] with privacy questions.
