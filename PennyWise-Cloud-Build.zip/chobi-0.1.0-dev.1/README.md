# PennyWise

PennyWise is an offline-first Android expense tracker and budget planner based on the Chobi Android project. This working copy applies a new product name, application ID, visual palette, launcher background, export filenames, and backup configuration while retaining the upstream transaction and budget foundation.

## Existing functionality

- Record income and expenses with categories and custom dates.
- Create and manage monthly budgets.
- Customize categories, icons, and colors.
- View spending summaries and budget insights.
- Store data locally using Room/SQLite.
- Export and import JSON/database backups at the user's request.
- Choose theme, currency, and time format.

## Technology

- Kotlin
- Jetpack Compose and Material 3
- Room / SQLite
- DataStore
- MVVM

## Important project notes

- The underlying application is derived from Chobi (`https://github.com/mrndstvndv/chobi`). See `PROJECT_ATTRIBUTION.md`.
- The upstream README declares MIT licensing but its repository currently does not expose the referenced `LICENSE` file. Obtain the original licence text and preserve the upstream copyright notice before redistribution or Google Play publication. This project does not invent or replace that licence.
- The privacy policy in `PRIVACY_POLICY_TEMPLATE.md` is a template. Complete publisher/contact details, verify it against the final binary, host it at a public HTTPS URL, and link it in the app and Play listing before submission.
- See `PLAY_STORE_RELEASE_CHECKLIST.md` for the remaining build, testing, security, and Play Console tasks.

## Build

Open this project in a current stable Android Studio installation with Android SDK 37 and JDK 17 configured. Sync Gradle, run the unit and instrumented tests, then build a signed release Android App Bundle. Do not commit signing keys or passwords.
