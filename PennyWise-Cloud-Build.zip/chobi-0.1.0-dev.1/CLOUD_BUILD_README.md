# Build PennyWise APK from a phone with GitHub Actions

This project includes `.github/workflows/android-apk.yml`.

1. Create a **new private GitHub repository** (for example `pennywise-android`).
2. Upload the *contents* of this project folder to the repository root. Do not upload only this ZIP as a single file, and do not put the project inside an extra nested folder.
3. Open the repository's **Actions** tab and enable Actions if GitHub asks.
4. Select **Build PennyWise APK** on the left, tap **Run workflow**, and run it on `main` (or `master`). A push to either branch also triggers the build.
5. Wait for the run to finish with a green check. Open the run, scroll to **Artifacts**, and download `PennyWise-debug-apk`.
6. Extract the downloaded artifact ZIP on your phone. Install the APK. Android may ask you to allow installs from the browser or file manager you used.

This workflow creates a **debug APK for testing**, not a Play Store release. For Google Play, create a signed release Android App Bundle (AAB) with a private upload key. Never put a keystore or passwords in the repository.
