# Project attribution and modifications

PennyWise is a modified student project based on the Chobi Android expense tracker source archive (release `v0.1.0-dev.1`). The upstream README states that Chobi is available under the MIT License and points to a `LICENSE` file; however, the source archive supplied for this modification did not contain that file.

Before redistribution or Google Play publication, obtain and retain the original MIT licence text and confirm the upstream copyright notice from the original repository/developer. Do not treat this note as a substitute for the licence. Preserve all upstream notices in any redistributed source and include the licence with the release.

Changes made in this working copy:
- Product display name changed to PennyWise.
- Application ID changed to `com.pennywise.studentfinance`.
- Branded palette and launcher background refreshed.
- Backup export filename changed to `pennywise_backup.json`.
- Android automatic backup disabled so locally stored financial entries are not silently included in Android cloud/device backup; users can still use the app's explicit export/restore controls.

The underlying transaction, budget, category, Room database, and settings implementation remains derived from Chobi. This project must not be represented as written entirely from scratch.
