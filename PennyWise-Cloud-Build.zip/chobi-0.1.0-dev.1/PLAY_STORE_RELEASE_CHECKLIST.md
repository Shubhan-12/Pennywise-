# Google Play release checklist — PennyWise

This is a preparation checklist, not a guarantee of Google Play approval.

## Source/build checks
- [ ] Obtain the upstream Chobi MIT licence text and preserve copyright notices before redistribution.
- [ ] Build a release variant with the current Android Gradle Plugin and SDK installed.
- [ ] Confirm `targetSdk` meets the current Play Console requirement at submission time (this project currently targets API 37).
- [ ] Run unit and instrumented tests on supported Android versions and screen sizes.
- [ ] Test add/edit/delete transaction, income/expense sign, date/time, categories, budgets, currency, import/export, and destructive database restore.
- [ ] Test backup files with malformed, oversized, and incompatible inputs; verify no data loss on failed imports.
- [ ] Generate a signed Android App Bundle (AAB) with a developer-owned upload key. Never commit keystore credentials.
- [ ] Verify package ID availability and ensure it is controlled by the publisher.

## Play Console declarations
- [ ] Host a complete privacy policy at a public HTTPS URL and link it in the store listing and app.
- [ ] Complete Data safety based on the exact release binary and all included SDKs. Do not assume the source-level analysis alone is sufficient.
- [ ] Complete the Financial features declaration accurately; this app is a personal expense/budget tracker and does not provide loans, banking, payments, investment advice, or financial products.
- [ ] Complete app access, ads, target audience, content rating, and other App content declarations truthfully.
- [ ] Prepare app icon, feature graphic, screenshots, store description, contact details, and support URL/email.
- [ ] Review current developer-account testing requirements. New personal developer accounts may need at least 12 opted-in testers for 14 continuous days before production access.
- [ ] Review current Android 16 KB page-size requirements and any applicable SDK compatibility requirements before submission.
- [ ] Declare trader status in Play Console if requested for the developer account/region.

## Release security
- [ ] Keep all personal financial data private; never publish sample/user database files.
- [ ] Do not upload a debug build or expose signing credentials.
- [ ] Test the final signed AAB on real devices before production rollout.
