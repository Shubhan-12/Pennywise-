package com.example.chobi.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "budgets")
data class Budget(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val limitAmount: Double,
    val startTimestamp: Long,
    val endTimestamp: Long? = null,
    @ColumnInfo(defaultValue = "0")
    val archived: Boolean = false
)
