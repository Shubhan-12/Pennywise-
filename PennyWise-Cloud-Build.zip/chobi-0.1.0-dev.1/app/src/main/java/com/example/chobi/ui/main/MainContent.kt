package com.example.chobi.ui.main

import android.icu.text.NumberFormat
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.chobi.data.Budget
import com.example.chobi.data.Category
import com.example.chobi.data.Expense
import com.example.chobi.data.getGroupHeader

import com.example.chobi.theme.ChobiTheme
import com.example.chobi.ui.components.ExpenseItem
import com.example.chobi.ui.components.SummaryCard
import java.util.Locale

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun MainContent(
  expenses: List<Expense>,
  categories: List<Category>,
  selectedBudget: Budget?,
  onDeleteExpense: (Expense) -> Unit,
  onBudgetsClick: () -> Unit,
  onSummaryCardClick: (Budget?) -> Unit,
  modifier: Modifier = Modifier,
  contentPadding: PaddingValues = PaddingValues(),
  currencyCode: String = "USD",
  timeFormatPreference: String = "auto",
  onExpenseClick: ((Expense) -> Unit)? = null
) {

  val filteredExpenses = remember(expenses, selectedBudget) {
    if (selectedBudget == null) expenses else expenses.filter { it.budgetId == selectedBudget.id }
  }

  val totalAmount = remember(filteredExpenses) { filteredExpenses.sumOf { it.amount } }
  val currencyFormatter = remember(currencyCode) {
    try {
      NumberFormat.getCurrencyInstance(Locale.getDefault()).apply {
        currency = android.icu.util.Currency.getInstance(currencyCode)
      }
    } catch (e: Exception) {
      NumberFormat.getCurrencyInstance(Locale.getDefault())
    }
  }

  val groupedExpenses = remember(filteredExpenses) {
    filteredExpenses.groupBy { expense ->
      getGroupHeader(expense.timestamp)
    }.mapValues { (_, items) -> items to items.sumOf { it.amount } }
  }

  // O(1) category lookup instead of O(n) firstOrNull per expense
  val categoryMap = remember(categories) {
    categories.associateBy { it.name.lowercase() }
  }

  if (filteredExpenses.isEmpty()) {
    Column(
      modifier = modifier.padding(contentPadding),
      verticalArrangement = Arrangement.Top
    ) {
      SummaryCard(
        expenses = filteredExpenses,
        totalAmount = totalAmount,
        selectedBudget = selectedBudget,
        onBudgetsClick = onBudgetsClick,
        onClick = { onSummaryCardClick(selectedBudget) },
        currencyCode = currencyCode,
        currencyFormatter = currencyFormatter,
        modifier = Modifier
          .fillMaxWidth()
          .padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 8.dp)
      )
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
      ) {
        Text(
          text = "¯\\_(ツ)_/¯",
          style = MaterialTheme.typography.headlineMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
          modifier = Modifier.padding(bottom = 12.dp)
        )
        Text(
          text = if (selectedBudget != null) "No expenses in this budget" else "No expenses added yet",
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
  } else {
    LazyColumn(
      // Insets are consumed so nested inset-aware components don't double-apply them,
      // while contentPadding keeps the first/last items clear of the system bars.
      modifier = modifier.consumeWindowInsets(contentPadding),
      contentPadding = contentPadding,
      verticalArrangement = Arrangement.spacedBy(ListItemDefaults.SegmentedGap)
    ) {
      // Summary/Wallet Card
      item {
        SummaryCard(
          expenses = filteredExpenses,
          totalAmount = totalAmount,
          selectedBudget = selectedBudget,
          onBudgetsClick = onBudgetsClick,
          onClick = { onSummaryCardClick(selectedBudget) },
          currencyCode = currencyCode,
          currencyFormatter = currencyFormatter,
          modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 8.dp)
        )
      }

      groupedExpenses.forEach { (header, pair) ->
        val (itemsForHeader, dayTotal) = pair
        item(key = "header_$header") {
          Row(
            modifier = Modifier
              .animateItem()
              .fillMaxWidth()
              .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = header,
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.primary
            )
            val isDayIncome = dayTotal < 0
            val dayDisplay = if (isDayIncome) "+${currencyFormatter.format(-dayTotal)}" else currencyFormatter.format(dayTotal)
            val dayColor = if (isDayIncome) androidx.compose.ui.graphics.Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant
            Text(
              text = dayDisplay,
              style = MaterialTheme.typography.titleMedium,
              color = dayColor
            )
          }
        }
        itemsIndexed(itemsForHeader, key = { _, it -> it.id }) { index, expense ->
          val matchingCategory = categoryMap[expense.category.lowercase()]
          ExpenseItem(
            expense = expense,
            category = matchingCategory,
            onDelete = { onDeleteExpense(expense) },
            currencyFormatter = currencyFormatter,
            timeFormatPreference = timeFormatPreference,
            onClick = { onExpenseClick?.invoke(expense) },
            shapes = ListItemDefaults.segmentedShapes(index, itemsForHeader.size),
            index = index,
            count = itemsForHeader.size,
            modifier = Modifier
              .animateItem()
              .padding(horizontal = 16.dp)
          )
        }
      }
    }
  }
}


@Preview(showBackground = true)
@Composable
fun MainScreenPreview() {
  ChobiTheme {
    MainContent(
      expenses = listOf(
        Expense(id = 1, title = "Lunch", amount = 15.50, category = "Food", timestamp = System.currentTimeMillis()),
        Expense(id = 2, title = "Bus", amount = 2.50, category = "Transport", timestamp = System.currentTimeMillis())
      ),
      categories = listOf(
        Category(id = 1, name = "Food", iconName = "Restaurant", colorHex = "#FF9800"),
        Category(id = 2, name = "Transport", iconName = "DirectionsCar", colorHex = "#2196F3")
      ),
      selectedBudget = null,
      onDeleteExpense = {},
      onBudgetsClick = {},
      onSummaryCardClick = {}
    )
  }
}
