package com.example.chobi.theme

import androidx.compose.ui.graphics.Color

// PennyWise brand palette: confident teal, deep midnight surfaces and warm amber accents.

// Light theme
val LightPrimary = Color(0xFF176B5B)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFB8EBDD)
val LightOnPrimaryContainer = Color(0xFF002117)

val LightSecondary = Color(0xFF426B78)
val LightOnSecondary = Color(0xFFFFFFFF)
val LightSecondaryContainer = Color(0xFFC5E8F2)
val LightOnSecondaryContainer = Color(0xFF001F28)

val LightTertiary = Color(0xFF8A5A00)
val LightOnTertiary = Color(0xFFFFFFFF)
val LightTertiaryContainer = Color(0xFFFFDFAE)
val LightOnTertiaryContainer = Color(0xFF2B1A00)

val LightBackground = Color(0xFFF5F8F7)
val LightOnBackground = Color(0xFF171D1B)
val LightSurface = Color(0xFFF5F8F7)
val LightOnSurface = Color(0xFF171D1B)
val LightSurfaceVariant = Color(0xFFDCE7E3)
val LightOnSurfaceVariant = Color(0xFF3E4945)
val LightOutline = Color(0xFF707C77)

// Dark theme
val DarkPrimary = Color(0xFF83D8C0)
val DarkOnPrimary = Color(0xFF00382D)
val DarkPrimaryContainer = Color(0xFF005143)
val DarkOnPrimaryContainer = Color(0xFFB8EBDD)

val DarkSecondary = Color(0xFFA9D2DF)
val DarkOnSecondary = Color(0xFF0B3540)
val DarkSecondaryContainer = Color(0xFF294D58)
val DarkOnSecondaryContainer = Color(0xFFC5E8F2)

val DarkTertiary = Color(0xFFFFC66D)
val DarkOnTertiary = Color(0xFF482900)
val DarkTertiaryContainer = Color(0xFF684000)
val DarkOnTertiaryContainer = Color(0xFFFFDFAE)

val DarkBackground = Color(0xFF101A19)
val DarkOnBackground = Color(0xFFE0E8E4)
val DarkSurface = Color(0xFF101A19)
val DarkOnSurface = Color(0xFFE0E8E4)
val DarkSurfaceVariant = Color(0xFF3D4A46)
val DarkOnSurfaceVariant = Color(0xFFBECAC5)
val DarkOutline = Color(0xFF899690)
